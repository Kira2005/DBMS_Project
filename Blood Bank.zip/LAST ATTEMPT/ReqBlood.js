document.getElementById('blood-request-form').addEventListener('submit', function(event) {
    event.preventDefault();

    // Get form values
    const name = document.getElementById('name').value;
    const bloodType = document.getElementById('blood-type').value;
    const units = document.getElementById('units').value;
    const contact = document.getElementById('contact').value;

    // Generate Payment Details
    const paymentId = `PAY-${Math.floor(1000 + Math.random() * 9000)}`;
    const paymentDate = new Date().toLocaleDateString();
    const amountPaid = `$${(units * 50).toFixed(2)}`; // Example: $50 per unit

    // Add a new row to the Requests Table
    const requestsTableBody = document.querySelector('#requests-table tbody');
    const newRequestRow = document.createElement('tr');
    newRequestRow.innerHTML = `
        <td style="padding: 10px; border: 1px solid #ccc;">${name}</td>
        <td style="padding: 10px; border: 1px solid #ccc;">${bloodType}</td>
        <td style="padding: 10px; border: 1px solid #ccc;">${units}</td>
        <td style="padding: 10px; border: 1px solid #ccc;">${contact}</td>
    `;
    requestsTableBody.appendChild(newRequestRow);

    // Add a new row to the Payment Table
    const paymentTableBody = document.querySelector('#payment-table tbody');
    const newPaymentRow = document.createElement('tr');
    newPaymentRow.innerHTML = `
        <td style="padding: 10px; border: 1px solid #ccc;">${paymentId}</td>
        <td style="padding: 10px; border: 1px solid #ccc;">${paymentDate}</td>
        <td style="padding: 10px; border: 1px solid #ccc;">${amountPaid}</td>
    `;
    paymentTableBody.appendChild(newPaymentRow);

    // Clear the form fields
    event.target.reset();
});
