$(document).ready(function () {
    // Initialize DataTable
    const table = $('#availability-table').DataTable({
        language: {
            emptyTable: "No data available in table",
        },
        pageLength: 4
    });

    // Event listener for the search button
    $('#search-btn').click(function () {
        const city = $('#city').val().trim();
        if (!city) {
            alert("Please enter a city name.");
            return;
        }

        // Simulate fetching data from a database
        const mockData = [
            { hospital: "City Hospital", branch: "Central", city: "Chennai", bloodType: "A+", units: 10 },
            { hospital: "Care Hospital", branch: "South", city: "Chennai", bloodType: "O-", units: 5 },
            { hospital: "HealthCare", branch: "East", city: "Mumbai", bloodType: "B+", units: 12 },
            { hospital: "LifeLine", branch: "West", city: "Chennai", bloodType: "AB+", units: 7 }
        ];

        // Filter data based on the city
        const filteredData = mockData.filter(data => data.city.toLowerCase() === city.toLowerCase());

        // Clear the table
        table.clear();

        // Populate the table with filtered data
        if (filteredData.length > 0) {
            filteredData.forEach(data => {
                table.row.add([
                    data.hospital,
                    data.branch,
                    data.city,
                    data.bloodType,
                    data.units
                ]).draw();
            });
        } else {
            alert("No data found for the entered city.");
        }
    });
});