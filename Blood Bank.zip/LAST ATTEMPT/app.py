from flask import Flask, jsonify, render_template, request
import psycopg2

app = Flask(__name__)

# PostgreSQL connection details
DB_HOST = "localhost"
DB_NAME = "bloodfinal"
DB_USER = "bhavana"
DB_PASSWORD = "likecrazyqueen"

def get_db_connection():
    """Create a database connection"""
    conn = psycopg2.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD
    )
    return conn

@app.route('/')
def homepage():
    return render_template('homepage.html')

@app.route('/check_avail')
def CheckAvail():
    return render_template('CheckAvail.html')

@app.route('/requestblood')
def RequestB():
    return render_template('RequestBlood.html')

@app.route('/login')
def Login():
    return render_template('index.html')

@app.route('/pay')
def Payment():
    return render_template('payment.html')

@app.route('/donor')
def Donor():
    return render_template('donor.html')

@app.route('/branch')
def Branch():
    return render_template('branch.html')
@app.route('/receiver')
def Receiver():
    return render_template('receiver.html')

@app.route('/search_hospitals', methods=['GET'])
def search_hospitals():
    city = request.args.get('city')
    c = get_db_connection()
    cursor = c.cursor()

    try:
        if city:
            query = """
                SELECT h.HospitalName, b.BranchName, b.City, bt.BloodGroup, bt.Total_Units
                FROM Hospital h
                JOIN Branch b ON h.City = b.City
                JOIN Distribution d ON b.Branch_ID = d.Branch_ID
                JOIN BloodType bt ON d.BloodType_ID = bt.BloodType_ID
                WHERE b.City = %s
            """
            cursor.execute(query, (city,))
        else:
            query = """
                SELECT h.HospitalName, b.BranchName, b.City, bt.BloodGroup, bt.Total_Units
                FROM Hospital h
                JOIN Branch b ON h.City = b.City
                JOIN Distribution d ON b.Branch_ID = d.Branch_ID
                JOIN BloodType bt ON d.BloodType_ID = bt.BloodType_ID
            """
            cursor.execute(query)

        results = cursor.fetchall()
        return jsonify(results)
    finally:
        cursor.close()

@app.route('/get_receivers', methods=['GET'])
def get_receivers():
    branch_id = request.args.get('branch_id')
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')
    c = get_db_connection()
    cursor = c.cursor()

    try:
        # SQL query to get receiver data based on the provided branch_id, from_date, and to_date
        cursor.execute("""
            SELECT 
                req.ReceiverID,
                p.Name AS ReceiverName,
                bt.BloodGroup AS BloodType,
                req.QuantityRequested AS UnitsRequired,
                r4.ReceiverContactNumber AS Contact
            FROM 
                Request req
            JOIN 
                Person p ON req.ReceiverID = p.Person_ID
            JOIN 
                R4 r4 ON req.ReceiverID = r4.Receiver_ID
            JOIN 
                Distribution dist ON dist.Branch_ID = req.Branch_ID
            JOIN 
                BloodType bt ON dist.BloodType_ID = bt.BloodType_ID
            WHERE 
                req.Branch_ID = %s
                AND req.RequestDate BETWEEN %s AND %s
            ORDER BY 
                req.RequestDate;
        """, (branch_id, from_date, to_date))

        results = cursor.fetchall()
        # Return the data as JSON
        return jsonify([
            {
                "ReceiverID": row[0],
                "ReceiverName": row[1],
                "BloodType": row[2],
                "UnitsRequired": row[3],
                "Contact": row[4]
            } for row in results
        ])

    except Exception as e:
        return jsonify({"error": str(e)}), 500

    finally:
        cursor.close()
@app.route('/search_branch', methods=['GET'])
def search_branch():
    city = request.args.get('city')  # Get the city query parameter from the request

    if not city:
        return jsonify({"error": "City parameter is required"}), 400

    cursor = get_db_connection().cursor()

    try:
        # Execute the query to get branch details based on the city
        cursor.execute("""
            SELECT 
                b.Branch_ID AS BranchID, 
                b.BranchName, 
                r2.HospitalContactNumber AS PhoneNumber
            FROM 
                Branch b
            JOIN 
                Hospital h ON b.City = h.City
            JOIN 
                R2 r2 ON h.Hospital_ID = r2.Hospital_ID
            WHERE
                b.city = %s;
        """, (city,))

        # Fetch the results
        results = cursor.fetchall()

        # Format the results into a list of dictionaries for easier processing in the frontend
        branches = [{"BranchID": row[0], "BranchName": row[1], "PhoneNumber": row[2]} for row in results]

        return jsonify(branches)  # Send the results back to the frontend

    finally:
        cursor.close()

@app.route('/get_donors', methods=['GET'])
def get_donors():
    # Get query parameters
    branch_id = request.args.get('branch_id')
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')

    if not branch_id or not from_date or not to_date:
        return jsonify({"error": "Missing required parameters"}), 400
    c = get_db_connection()

    cursor = c.cursor()

    try:
        # Query the database
        query = """
            SELECT 
                p.DonorID AS Donor_ID,
                p.Name AS Donor_Name,
                bt.BloodGroup AS Blood_Type,
                MAX(d.DonationDate) AS Last_Donation_Date,
                r3.DonorContactNumber AS Contact
            FROM 
                Donation d
            JOIN 
                Person p ON d.DonorID = p.Person_ID
            JOIN 
                R3 r3 ON p.Person_ID = r3.Donor_ID
            JOIN 
                R11 r11 ON d.DonationID = r11.DonationID
            JOIN 
                BloodType bt ON r11.BloodType_ID = bt.BloodType_ID
            WHERE 
                d.Branch_ID = %s 
                AND d.DonationDate BETWEEN %s AND %s 
            GROUP BY 
                p.DonorID, p.Name, bt.BloodGroup, r3.DonorContactNumber
            ORDER BY 
                Last_Donation_Date DESC
        """
        cursor.execute(query, (branch_id, from_date, to_date))
        results = cursor.fetchall()

        # Format the results into a list of dictionaries
        donors = [
            {
                "donor_id": row[0],
                "name": row[1],
                "blood_type": row[2],
                "last_donation_date": row[3].strftime('%Y-%m-%d'),  # Format date as string
                "contact": row[4]
            }
            for row in results
        ]

        return jsonify(donors)  # Return results as JSON
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()

@app.route('/payment_records', methods=['GET'])
def payment_records():
    branch_id = request.args.get('branch_id')  # Get the branch ID from the query params
    from_date = request.args.get('from_date')  # Get the from date
    to_date = request.args.get('to_date')      # Get the to date
    c = get_db_connection()
    cursor = c.cursor()

    try:
        # SQL query to fetch payment records based on the given criteria
        cursor.execute("""
            SELECT 
                p.Payment_ID, 
                r.Branch_ID, 
                p.PaymentDate, 
                ra.AmountPaid
            FROM 
                Payment p
            JOIN 
                Request r ON p.RequestID = r.RequestID
            JOIN 
                RequestAmount ra ON r.RequestID = ra.RequestID
            WHERE 
                r.Branch_ID = %s 
                AND p.PaymentDate BETWEEN %s AND %s
        """, (branch_id, from_date, to_date))

        results = cursor.fetchall()
        return jsonify(results)  # Send the data back as JSON

    except Exception as e:
        return jsonify({"error": str(e)}), 500

    finally:
        cursor.close()

@app.route('/payment_record', methods=['GET'])
def payment_record():
    # Get query parameters from the URL
    branch_name = request.args.get('branch_name')
    city = request.args.get('city')
    c = get_db_connection()
    
    cursor = c.cursor()

    try:
        # SQL query to fetch payment records based on branch name and city
        cursor.execute("""
            SELECT 
                p.Name AS "Name",
                bt.BloodGroup AS "Blood Type",
                r11.QuantityRequested AS "Units",
                r4.ReceiverContactNumber AS "Contact",
                pm.Payment_ID AS "Payment ID",
                pm.PaymentDate AS "Payment Date",
                ra.AmountPaid AS "Amount Paid"
            FROM Branch b
            INNER JOIN R11 r11 ON b.Branch_ID = r11.Branch_ID
            INNER JOIN BloodType bt ON r11.BloodType_ID = bt.BloodType_ID
            INNER JOIN Person p ON r11.ReceiverID = p.Person_ID
            INNER JOIN R4 r4 ON r11.ReceiverID = r4.Receiver_ID
            INNER JOIN Request rq ON r11.RequestID = rq.RequestID
            INNER JOIN Payment pm ON rq.RequestID = pm.RequestID
            INNER JOIN RequestAmount ra ON rq.RequestID = ra.RequestID
            WHERE b.BranchName = %s
            AND b.City = %s
        """, (branch_name, city))

        # Fetch all results
        results = cursor.fetchall()

        # Return results as JSON
        return jsonify(results)

    finally:
        cursor.close()

@app.route('/get_branchid', methods=['GET'])
def get_branchid():
    try:
        # Connect to the database
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                # Execute the query
                cur.execute("SELECT Branch_ID FROM Branch")
                # Fetch and format results
                branch_ids = [row[0] for row in cur.fetchall()]
        # Return the list of branch IDs as JSON
        return jsonify(branch_ids), 200
    except Exception as e:
        # Handle exceptions and return an error response
        return jsonify({'error': str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True)
